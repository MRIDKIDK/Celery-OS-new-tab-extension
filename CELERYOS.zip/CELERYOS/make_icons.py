
import struct
import zlib
from pathlib import Path

BG = (10, 15, 18, 255)
GREEN = (57, 255, 120, 255)

def png_chunk(kind, data):
    body = kind + data
    return (
        struct.pack(">I", len(data))
        + body
        + struct.pack(">I", zlib.crc32(body) & 0xffffffff)
    )

def create_icon(size):
    pixels = bytearray(BG * (size * size))

    def rect(x1, y1, x2, y2):
        x1 = max(0, int(x1 * size / 128))
        y1 = max(0, int(y1 * size / 128))
        x2 = min(size, int(x2 * size / 128))
        y2 = min(size, int(y2 * size / 128))

        for y in range(y1, y2):
            for x in range(x1, x2):
                i = (y * size + x) * 4
                pixels[i:i+4] = bytes(GREEN)

    # Neon-green border
    rect(0, 0, 128, 4)
    rect(0, 124, 128, 128)
    rect(0, 0, 4, 128)
    rect(124, 0, 128, 128)

    # Draw a proper > symbol using diagonal blocks
    for i in range(8):
        rect(32 + i*4, 35 + i*4, 44 + i*4, 43 + i*4)
        rect(32 + i*4, 85 - i*4, 44 + i*4, 93 - i*4)

    # Terminal underscore
    rect(70, 83, 101, 91)

    raw = bytearray()
    stride = size * 4
    for y in range(size):
        raw.append(0)
        raw.extend(pixels[y*stride:(y+1)*stride])

    data = (
        b"\x89PNG\r\n\x1a\n"
        + png_chunk(b"IHDR", struct.pack(">IIBBBBB", size, size, 8, 6, 0, 0, 0))
        + png_chunk(b"IDAT", zlib.compress(bytes(raw), 9))
        + png_chunk(b"IEND", b"")
    )

    Path(f"icon{size}.png").write_bytes(data)
    print(f"Created icon{size}.png")

for size in (16, 32, 48, 128):
    create_icon(size)

print("CELERY OS icons fixed!")
