
"use strict";

/* ========================================
   CELERY OS 2.0
   Hacker dashboard + Google search
   ======================================== */

const $ = (id) => document.getElementById(id);

const STORAGE = {
  shortcuts: "celery_shortcuts_v2",
  username: "celery_username_v2",
  accent: "celery_accent_v2",
  notes: "celery_notes_v2"
};

const defaultShortcuts = [
  { name: "YouTube", url: "https://www.youtube.com", symbol: "▶" },
  { name: "GitHub", url: "https://github.com", symbol: "⌘" },
  { name: "Wikipedia", url: "https://www.wikipedia.org", symbol: "W" },
  { name: "ChatGPT", url: "https://chatgpt.com", symbol: "✳" }
];

function loadData(key, fallback) {
  try {
    const saved = localStorage.getItem(key);
    return saved === null ? fallback : JSON.parse(saved);
  } catch {
    return fallback;
  }
}

function saveData(key, value) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
    return true;
  } catch {
    return false;
  }
}

let shortcuts = loadData(STORAGE.shortcuts, defaultShortcuts);

if (!Array.isArray(shortcuts)) {
  shortcuts = [...defaultShortcuts];
}

let username = loadData(STORAGE.username, "USER");
let accent = loadData(STORAGE.accent, "green");

/* CLOCK AND DATE */

function updateClock() {
  const now = new Date();

  $("clock").textContent = now.toLocaleTimeString([], {
    hour: "2-digit",
    minute: "2-digit",
    second: "2-digit",
    hour12: false
  });

  $("date").textContent = now.toLocaleDateString([], {
    weekday: "long",
    day: "numeric",
    month: "long",
    year: "numeric"
  });
}

updateClock();
setInterval(updateClock, 1000);

/* SETTINGS */

const accentColours = {
  green: {
    main: "#b6ff00",
    soft: "#b6ff001c"
  },
  cyan: {
    main: "#00e5ff",
    soft: "#00e5ff1c"
  },
  amber: {
    main: "#ffbd39",
    soft: "#ffbd391c"
  }
};

function applySettings() {
  const chosen = accentColours[accent] || accentColours.green;

  document.documentElement.style.setProperty("--accent", chosen.main);
  document.documentElement.style.setProperty("--accent-soft", chosen.soft);

  $("welcome").textContent =
    "WELCOME BACK, " + String(username || "USER").toUpperCase() + ".";

  $("usernameInput").value = username || "USER";
  $("accentSelect").value = accent;
}

applySettings();

$("openSettings").addEventListener("click", () => {
  $("settingsDialog").showModal();
});

$("saveSettings").addEventListener("click", () => {
  username = $("usernameInput").value.trim().slice(0, 24) || "USER";
  accent = $("accentSelect").value;

  saveData(STORAGE.username, username);
  saveData(STORAGE.accent, accent);

  applySettings();
  $("settingsDialog").close();
});

/* GOOGLE SEARCH */

$("searchForm").addEventListener("submit", (event) => {
  event.preventDefault();

  const query = $("searchInput").value.trim();

  if (!query) {
    $("searchInput").focus();
    return;
  }

  window.location.href =
    "https://www.google.com/search?q=" + encodeURIComponent(query);
});

/* QUICK ACCESS SHORTCUTS */

function renderShortcuts() {
  const container = $("shortcuts");
  container.replaceChildren();

  shortcuts.forEach((shortcut, index) => {
    const card = document.createElement("a");
    card.className = "shortcut";
    card.href = shortcut.url;
    card.title = shortcut.url;

    const symbol = document.createElement("span");
    symbol.className = "shortcut-symbol";
    symbol.textContent = shortcut.symbol || "↗";

    const name = document.createElement("span");
    name.className = "shortcut-name";
    name.textContent = shortcut.name;

    const url = document.createElement("span");
    url.className = "shortcut-url";
    url.textContent = shortcut.url.replace(/^https?:\/\//, "");

    card.append(symbol, name, url);

    const remove = document.createElement("button");
    remove.type = "button";
    remove.className = "remove-shortcut";
    remove.textContent = "×";
    remove.title = "Remove " + shortcut.name;
    remove.setAttribute("aria-label", "Remove " + shortcut.name);

    remove.addEventListener("click", (event) => {
      event.preventDefault();
      event.stopPropagation();

      shortcuts.splice(index, 1);
      saveData(STORAGE.shortcuts, shortcuts);
      renderShortcuts();
    });

    card.appendChild(remove);
    container.appendChild(card);
  });
}

renderShortcuts();

$("addShortcut").addEventListener("click", () => {
  $("shortcutForm").reset();
  $("shortcutDialog").showModal();
});

$("shortcutForm").addEventListener("submit", (event) => {
  event.preventDefault();

  const name = $("shortcutName").value.trim();
  let url = $("shortcutUrl").value.trim();

  if (!name || !url) return;

  if (!/^https?:\/\//i.test(url)) {
    url = "https://" + url;
  }

  try {
    const parsed = new URL(url);

    if (!["http:", "https:"].includes(parsed.protocol)) {
      alert("Please enter a normal website address.");
      return;
    }

    url = parsed.href;
  } catch {
    alert("That website address doesn't look valid.");
    return;
  }

  if (shortcuts.length >= 20) {
    alert("Maximum 20 shortcuts. Remove one before adding another.");
    return;
  }

  shortcuts.push({
    name: name.slice(0, 20),
    url,
    symbol: "↗"
  });

  saveData(STORAGE.shortcuts, shortcuts);
  renderShortcuts();
  $("shortcutDialog").close();
});

/* DEMO TERMINAL
   Commands are simulated. They do not execute system commands.
*/

function terminalLine(text, className = "") {
  const line = document.createElement("p");

  if (className) {
    line.className = className;
  }

  line.textContent = text;
  $("terminalOutput").appendChild(line);
  $("terminalOutput").scrollTop = $("terminalOutput").scrollHeight;
}

function runCommand(rawCommand) {
  const command = rawCommand.trim().toLowerCase();

  if (!command) return;

  terminalLine("user@celery:~$ " + rawCommand, "command-line");

  switch (command) {
    case "help":
      terminalLine("AVAILABLE COMMANDS:");
      terminalLine("help     - Show this command list");
      terminalLine("about    - About CELERY OS");
      terminalLine("version  - Show version");
      terminalLine("date     - Show current date");
      terminalLine("time     - Show current time");
      terminalLine("whoami   - Show dashboard username");
      terminalLine("status   - Show demo system status");
      terminalLine("apps     - List dashboard modules");
      terminalLine("clear    - Clear terminal output");
      break;

    case "about":
      terminalLine("CELERY OS is a custom browser dashboard.");
      terminalLine("Built with HTML, CSS and JavaScript.");
      break;

    case "version":
      terminalLine("CELERY OS version 2.0.0");
      terminalLine("Manifest V3 browser extension.");
      break;

    case "date":
      terminalLine(new Date().toLocaleDateString());
      break;

    case "time":
      terminalLine(new Date().toLocaleTimeString());
      break;

    case "whoami":
      terminalLine(username || "USER");
      break;

    case "status":
      terminalLine("Dashboard: ONLINE");
      terminalLine("Google search: READY");
      terminalLine("Terminal: DEMO MODE");
      terminalLine("Local storage: " + (
        (() => {
          try {
            localStorage.setItem("__celery_test", "1");
            localStorage.removeItem("__celery_test");
            return "AVAILABLE";
          } catch {
            return "UNAVAILABLE";
          }
        })()
      ));
      break;

    case "apps":
      terminalLine("1. Google Search");
      terminalLine("2. Quick Access");
      terminalLine("3. Local Notes");
      terminalLine("4. System Info");
      break;

    case "clear":
      $("terminalOutput").replaceChildren();
      return;

    default:
      terminalLine("Command not found: " + rawCommand);
      terminalLine("Type 'help' to see available commands.");
  }
}

$("terminalForm").addEventListener("submit", (event) => {
  event.preventDefault();

  const input = $("terminalInput");
  const command = input.value;

  input.value = "";
  runCommand(command);
});

$("clearTerminal").addEventListener("click", () => {
  $("terminalOutput").replaceChildren();
  terminalLine("Terminal cleared.");
  terminalLine("Type 'help' to see available commands.");
});

/* NOTES */

$("notesInput").value = loadData(STORAGE.notes, "");

$("saveNotes").addEventListener("click", () => {
  const success = saveData(STORAGE.notes, $("notesInput").value);

  $("notesStatus").textContent = success
    ? "NOTES SAVED ON THIS DEVICE."
    : "COULDN'T SAVE. Browser storage may be unavailable.";
});

$("notesInput").addEventListener("input", () => {
  $("notesStatus").textContent = "Unsaved changes.";
});

/* MODULE BUTTONS */

document.querySelectorAll("[data-module]").forEach((button) => {
  button.addEventListener("click", () => {
    const moduleName = button.dataset.module;

    if (moduleName === "terminal") {
      $("terminalPanel").scrollIntoView({
        behavior: "smooth",
        block: "center"
      });

      $("terminalInput").focus();
    }

    if (moduleName === "notes") {
      $("notesStatus").textContent = "";
      $("notesDialog").showModal();
      $("notesInput").focus();
    }

    if (moduleName === "system") {
      $("systemDialog").showModal();
    }
  });
});

/* STARTUP MESSAGE */

console.log("CELERY OS 2.0 loaded.");
console.log("Google search enabled.");
console.log("Demo terminal ready.");
